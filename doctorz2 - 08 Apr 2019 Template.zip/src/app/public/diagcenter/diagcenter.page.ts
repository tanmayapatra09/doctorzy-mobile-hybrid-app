import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diagcenter',
  templateUrl: './diagcenter.page.html',
  styleUrls: ['./diagcenter.page.scss'],
})
export class DiagcenterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

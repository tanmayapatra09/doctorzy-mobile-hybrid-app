import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingconfirmation',
  templateUrl: './bookingconfirmation.page.html',
  styleUrls: ['./bookingconfirmation.page.scss'],
})
export class BookingconfirmationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

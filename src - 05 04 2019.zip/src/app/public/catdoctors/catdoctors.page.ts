import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catdoctors',
  templateUrl: './catdoctors.page.html',
  styleUrls: ['./catdoctors.page.scss'],
})
export class CatdoctorsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

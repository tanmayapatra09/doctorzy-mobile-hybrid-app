import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myservicepage',
  templateUrl: './myservicepage.page.html',
  styleUrls: ['./myservicepage.page.scss'],
})
export class MyservicepagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

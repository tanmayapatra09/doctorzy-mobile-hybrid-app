import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individualprofile',
  templateUrl: './individualprofile.page.html',
  styleUrls: ['./individualprofile.page.scss'],
})
export class IndividualprofilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

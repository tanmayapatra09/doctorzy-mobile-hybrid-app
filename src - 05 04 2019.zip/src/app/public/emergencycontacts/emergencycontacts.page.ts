import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emergencycontacts',
  templateUrl: './emergencycontacts.page.html',
  styleUrls: ['./emergencycontacts.page.scss'],
})
export class EmergencycontactsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
